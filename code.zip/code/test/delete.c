#include "syscall.h"
#define MAXLENGTH 256
int main() {
    int result;
    char filename[MAXLENGTH];
    PrintString("Enter the filename: ");
    ReadString(filename, MAXLENGTH);
    result = Remove(filename);
    
    if (result == -1) {
        PrintString("Unable to delete file.\n");
    }
    if (result == 0) {
        PrintString("File delete successfully.\n");
    }
    Halt();
}