#include "syscall.h"
#define BUFFER_SIZE 256
int main() {
    char filename[BUFFER_SIZE];
    int fileId;

    // Yêu cầu người dùng nhập tên file hoặc đọc tên file từ console
    PrintString("Enter the filename: ");
    ReadString(filename, BUFFER_SIZE);
    // Tạo file với tên đã cho sử dụng system call Create
    fileId = Create(filename);

    if (fileId == -1) {
        PrintString("Error: Unable to create the file.\n");
        Halt();
    }
    else {
        PrintString("File created successfully.\n");
    }

    Halt();
}