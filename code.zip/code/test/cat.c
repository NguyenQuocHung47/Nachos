#include "syscall.h"

#define BUFFER_SIZE 256
int main() {
	char filename[BUFFER_SIZE]; 
	char buffer[BUFFER_SIZE];
	int bytesRead;
	int fileId;
	int lengthFile; 
	PrintString("Enter the filename: ");
	ReadString(filename, BUFFER_SIZE);
		
	
	fileId = Open(filename, 1);
	if (fileId < 0) {
		PrintString("Error: Unable to open the file.\n");
		Halt();
	}
	lengthFile = Seek(fileId, -1);
	Seek(fileId, 0);

	if ((bytesRead = Read(buffer, lengthFile, fileId)) > 0) {
		PrintString("Result after read file: \n");
		PrintString(buffer);
	}

	Close(fileId);
	Halt();
}