#include "syscall.h" 
#include "copyright.h" 
#define maxlen 32 
int 
main() 
{ 
 CreateFile("filet.txt");
 return 0;
}