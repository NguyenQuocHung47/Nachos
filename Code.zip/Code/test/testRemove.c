#include "syscall.h"

int
main() {
	Seek("file.txt")
	return 0;
}